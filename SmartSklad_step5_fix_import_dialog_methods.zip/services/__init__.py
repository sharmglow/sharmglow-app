"""Сервисный слой SmartSklad."""
